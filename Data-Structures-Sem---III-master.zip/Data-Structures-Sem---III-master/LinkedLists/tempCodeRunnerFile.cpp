ToHead(5);
    // obj.removeFromTail();
    // obj.displ